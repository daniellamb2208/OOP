# man Makefile 

```make```
produce a.elf b.elf c.elf d.elf

a.elf, b.elf for src/c main.c and main2.c
c.elf, d.elf for src/cpp main.cpp and main2.cpp

```make clean```
delete the file after make

```make clean dep all```
for homework required to update the modification @echo